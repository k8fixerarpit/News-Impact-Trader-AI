print('Backtest template placeholder')
